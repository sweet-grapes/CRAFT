import math
import os.path

import torch
import imageio
import numpy as np
import torchvision.transforms as T
from torch.utils.data import Dataset
from dataset.randaugment import RandAugmentMC

MEAN = (0.485, 0.456, 0.406)
STD = (0.229, 0.224, 0.225)


def get_GIF(train_list_path, test_list_path, data_root, num_classes, split_ratio):

    transform_test = T.Compose(
            [T.ToPILImage(),
             T.Resize((224, 224)),
             T.ToTensor(),
             T.Normalize(MEAN, STD)])
    # 细粒度标签标记的动图的转换
    transform_labeled = T.Compose([
        T.ToPILImage(),
        T.RandomHorizontalFlip(),
        T.Resize((224, 224)),
        T.RandomCrop(size=224, padding=int(224 * 0.125), padding_mode='reflect'),
        T.ToTensor(), T.Normalize(mean=MEAN, std=STD)])
    # 细粒度标记的训练动图和粗粒度弱标记的训练动图的分割
    train_labeled_idxs, train_weakly_labeled_idxs = x_w_split(train_list_path, num_classes, split_ratio)
    train_labeled_dataset = GIFTrainSet(train_list_path, data_root, train_labeled_idxs, transform=transform_labeled)
    train_weakly_labeled_dataset = GIFTrainSet(train_list_path, data_root, train_weakly_labeled_idxs, transform=TransformFixMatch(mean=MEAN, std=STD))
    test_dataset = GIFTestSet(test_list_path, data_root, transform=transform_test)

    return train_labeled_dataset, train_weakly_labeled_dataset, test_dataset


def x_w_split(train_list_path, num_fine_classes, ratio):
    # num_labeled = 0
    labels = []
    with open(train_list_path, "r") as f:
        for GIF in f.readlines():
            GIF = GIF.rstrip('\n')
            labels.append(int(GIF.split(' ')[1]))
    labels = np.array(labels)

    labeled_idx = []  # 训练集中细粒度标记的样本的索引
    weakly_labeled_idx = np.array(range(len(labels)))  # 训练集中粗粒度弱标记的样本的索引，此处将训练集中的所有动图都用做粗粒度标记的样本，严格点应该1 - ratio

    for i in range(num_fine_classes):
        index = np.where(labels == i)[0]
        # num_labeled += len(index) // args.ratio
        index = np.random.choice(index, int(len(index) * ratio), False)  # 选取训练集的 ratio 作为细粒度标签标记的动图
        labeled_idx.extend(index)
    labeled_idx = np.array(labeled_idx)
    '''
        if args.expand_labels or num_labeled < args.batch_size:
        num_expand_x = math.ceil(
            args.batch_size * args.eval_step / num_labeled)
        labeled_idx = np.hstack([labeled_idx for _ in range(num_expand_x)])
    '''
    np.random.shuffle(labeled_idx)
    return labeled_idx, weakly_labeled_idx


class TransformFixMatch(object):
    def __init__(self, mean, std):
        self.weak = T.Compose([
            T.ToPILImage(),
            T.RandomHorizontalFlip(),
            T.Resize((224, 224)),
            T.RandomCrop(size=224, padding=int(224*0.125), padding_mode='reflect')])
        self.strong = T.Compose([
            T.ToPILImage(),
            T.RandomHorizontalFlip(),
            T.Resize((224, 224)),
            T.RandomCrop(size=224, padding=int(224*0.125), padding_mode='reflect'),
            RandAugmentMC(n=2, m=10)])
        self.normalize = T.Compose([
            T.ToTensor(),
            T.Normalize(mean=mean, std=std)])

    def __call__(self, x):
        weak = self.weak(x)
        strong = self.strong(x)
        return self.normalize(weak), self.normalize(strong)


class GIFTrainSet(Dataset):
    def __init__(self, train_list_path, data_root, indexs, transform=None):
        super().__init__()
        self.transform = transform
        _list = []
        with open(train_list_path, "r") as f:
            for GIF in f.readlines():
                GIF = GIF.rstrip('\n')
                GIF_path = os.path.join(data_root, 'train_gif', GIF.split(' ')[0])
                GIF_label = GIF.split(' ')[1]
                GIF_coarse_label = GIF.split(' ')[2]
                _list.append((GIF_path, int(GIF_label), int(GIF_coarse_label)))

        # if indexs is not None:
        #     self.GIF_list = np.array(self.GIF_list, dtype=object)
        #     self.GIF_list = self.GIF_list[indexs].tolist()
        self.GIF_list = []
        for i in indexs:
            self.GIF_list.append(_list[i])


    def __getitem__(self, idx):
        gif_path = self.GIF_list[idx][0]
        label = self.GIF_list[idx][1]
        coarse_label = self.GIF_list[idx][2]

        # Read all frames
        frames = []
        for i in imageio.get_reader(gif_path):
            # Process single channel GIF
            if len(i.shape) == 2:
                i = np.stack([i] * 3, axis=-1)

            frames.append(i[:, :, :3])

        frames = np.array(frames)

        num_frames = frames.shape[0]
        if num_frames >= 8:
            # Sample some frames throughout the sequence
            sampled_frame_idx = np.random.choice(num_frames, 8, replace=False)
            sampled_frame_idx = np.sort(sampled_frame_idx)
            frames = frames[sampled_frame_idx]
        else:
            # Pad with edge
            num_frames_delta = 8 - num_frames
            frames = np.pad(frames,
                            pad_width=[(num_frames_delta // 2, num_frames_delta - num_frames_delta // 2), (0, 0),
                                       (0, 0), (0, 0)], mode='edge')

        if self.transform is not None:
            transformed_frames = [self.transform(i) for i in frames]
            if isinstance(transformed_frames[0], (tuple, list)):
                frames = torch.stack([f[0] for f in transformed_frames], dim=0), torch.stack([f[1] for f in transformed_frames], dim=0)
            else:
                frames = torch.stack(transformed_frames)
        return frames, label, coarse_label

    def __len__(self):
        return len(self.GIF_list)


class GIFTestSet(Dataset):

    def __init__(self, test_list_path, data_root, transform=None):
        super().__init__()
        self.transform = transform
        self.GIF_list = []
        with open(test_list_path, "r") as f:
            for GIF in f.readlines():
                GIF = GIF.rstrip('\n')
                GIF_path = os.path.join(data_root, 'test_gif', GIF.split(' ')[0])
                GIF_label = GIF.split(' ')[1]
                self.GIF_list.append((GIF_path, int(GIF_label)))

    def __getitem__(self, idx):
        gif_path = self.GIF_list[idx][0]
        gif_label = self.GIF_list[idx][1]  # 动图的细粒度标签

        # Read all frames
        frames = []
        for i in imageio.get_reader(gif_path):
            # Process single channel GIF
            if len(i.shape) == 2:
                i = np.stack([i] * 3, axis=-1)

            frames.append(i[:, :, :3])

        frames = np.array(frames)

        num_frames = frames.shape[0]
        if num_frames >= 8:
            # Sample some frames throughout the sequence
            frames_idx = np.round(np.linspace(0, num_frames - 1, 8)).astype(np.uint)
            frames = frames[frames_idx]
        else:
            # Pad with edge
            num_frames_delta = 8 - num_frames
            frames = np.pad(frames,
                            pad_width=[(num_frames_delta // 2, num_frames_delta - num_frames_delta // 2), (0, 0),
                                       (0, 0), (0, 0)], mode='edge')
        if self.transform is not None:
            transformed_frames = [self.transform(i) for i in frames]
            if isinstance(transformed_frames[0], (tuple, list)):
                frames = torch.stack([f[0] for f in transformed_frames], dim=0), torch.stack([f[1] for f in transformed_frames], dim=0)
            else:
                frames = torch.stack(transformed_frames)

        return frames, gif_label

    def __len__(self):
        return len(self.GIF_list)


if __name__ == '__main__':
    train_labeled_dataset, train_weakly_labeled_dataset, test_dataset = \
        get_GIF('/home/deserts/mayongjuan3/data/train_set1.txt', '/home/deserts/mayongjuan3/data/test_set1.txt',
                '/home/deserts/mayongjuan3/data/',
                73, 0.5)
    print(len(train_labeled_dataset), len(train_weakly_labeled_dataset), len(test_dataset))
    print(train_weakly_labeled_dataset[1000])

