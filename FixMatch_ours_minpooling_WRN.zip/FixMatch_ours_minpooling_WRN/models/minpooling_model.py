from .resnets import resnet18, resnet34, resnet50, resnet101, resnet152
import torch.nn as nn
import torch.nn.functional as F
import torch

c2f = [[1, 22, 24, 31, 51, 52, 53, 59],
       [10, 21, 39, 63],
       [6, 49, 55, 60, 64],
       [41, 42, 62],
       [0, 5, 16, 23, 61],
       [19, 34],
       [8, 9, 36, 37, 40, 43, 66],
       [32, 33, 50, 56],
       [2, 11, 25, 26, 27, 28, 68, 71],
       [12, 13, 14, 30, 35],
       [3, 29, 57, 58, 72],
       [45, 47, 54],
       [4, 70],
       [7, 15, 17, 18, 20, 38, 44, 46, 48, 65, 67, 69]
       ]


class SAttention(nn.Module):
    """
    sa = SAttention(2048)
    print(sa.forward(torch.randn(2*32, 2048, 32, 32), torch.randn(2*32, 73)).shape)
    """
    def __init__(self, num_channels, num_frames=32, reduction=16):
        super(SAttention, self).__init__()
        self.num_frames = num_frames
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(num_channels, num_channels // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(num_channels // reduction, 1, bias=False)
        )

    def forward(self, x, z1, z2):
        """
        x: features
        z1, z2: predictions, (B*T,#classes)
        """
        b, c, h, w = x.size()               # (B*T, C, H, W)
        x = self.avg_pool(x).view(b, c)     # (B*T, C)
        y = self.fc(x)                      # (B*T, 1)
        y = y.view(-1, self.num_frames)     # (B, T)
        att = F.softmax(y, dim=1)
        # T帧分类结果聚合
        z1 = z1.view(-1, self.num_frames, z1.size(-1)) * att.unsqueeze(-1)
        z1 = z1.sum(1)                        # (B, T, C)
        z2 = z2.view(-1, self.num_frames, z2.size(-1)) * att.unsqueeze(-1)
        z2 = z2.sum(1)
        return z1, z2, y


class DCEHAAModel(nn.Module):
    def __init__(self, backbone='resnet50', num_classes=73, num_frames=32):
        super(DCEHAAModel, self).__init__()
        if backbone == 'resnet50':
            self.backbone = resnet50(pretrained=True, num_classes=num_classes)
        else:
            raise NotImplementedError
        self.ts_attn = SAttention(2048, num_frames=num_frames)
        self.dropout = nn.Dropout2d(p=0.5)
        self.classifier = nn.Conv2d(2048, num_classes, 1)
        #
        self.bn_frozen_layers = []
        self.fixed_layers = [self.backbone.conv1, self.backbone.bn1]
        self._fix_running_stats(self.backbone, fix_params=True)

    def train(self, mode=True):
        super().train(mode)
        for l in self.fixed_layers:
            for p in l.parameters():
                p.requires_grad = False
        for bn_layer in self.bn_frozen_layers:
            bn_layer.eval()

    def _fix_running_stats(self, layer, fix_params=False):
        if isinstance(layer, (nn.BatchNorm2d, nn.BatchNorm1d, nn.SyncBatchNorm)):
            self.bn_frozen_layers.append(layer)
            if fix_params and not layer in self.fixed_layers:
                self.fixed_layers.append(layer)
        elif isinstance(layer, list):
            for m in layer:
                self._fix_running_stats(m, fix_params)
        else:
            for m in layer.children():
                self._fix_running_stats(m, fix_params)

    def forward(self, x):
        # (B, T, 3, H, W)
        B, T, C, H, W = x.shape
        x = x.view(B*T, C, H, W)
        _deprecated_frame_preds, feat = self.backbone.forward_feats(x)
        # 构造分类结果
        feat = self.dropout(feat)
        pred = self.classifier(feat)
        pred_fine = F.adaptive_avg_pool2d(pred, (1, 1))
        pred_fine = pred_fine.view(pred_fine.shape[0], pred_fine.shape[1])
        pred_map = [torch.min(pred[:, c2f[i], :, :], 1, keepdim=True)[0] for i in range(len(c2f))]
        pred_map = torch.cat(pred_map, dim=1)
        pred_coarse = F.adaptive_avg_pool2d(pred_map, (1, 1))
        pred_coarse = pred_coarse.view(pred_coarse.shape[0], pred_coarse.shape[1])
        # T帧分类结果聚合
        pred_fine_aggregation, pred_coarse_aggregation, atte = self.ts_attn(feat, pred_fine, pred_coarse)
        return (pred_fine_aggregation, pred_coarse_aggregation), atte, (pred_fine, pred_coarse)


def build_model(backbone='resnet50', num_classes=73, num_frames=8):
    return DCEHAAModel(backbone=backbone, num_classes=num_classes, num_frames=num_frames)